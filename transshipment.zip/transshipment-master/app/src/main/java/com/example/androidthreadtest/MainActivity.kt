package com.example.androidthreadtest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.widget.Button
import android.widget.TextView
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val changBtn : Button = findViewById(R.id.changeTextBtn)
        val textView : TextView = findViewById(R.id.textView)

        //异步消息处理机制
        val updateText = 1

        val handler = object:Handler(Looper.getMainLooper()){

            override fun handleMessage(msg: Message) {
                when(msg.what){
                    updateText  -> textView.text = "Nice to meet you"
                }
            }
        }

        changBtn.setOnClickListener{
            /**  在子线程中修改UI，不符合Android规定，会崩溃
             thread{
                textView.text = "Nice to meet you"
            }
            */

            thread{
                val msg = Message()
                msg.what = updateText
                handler.sendMessage(msg)
            }

        }
    }
}